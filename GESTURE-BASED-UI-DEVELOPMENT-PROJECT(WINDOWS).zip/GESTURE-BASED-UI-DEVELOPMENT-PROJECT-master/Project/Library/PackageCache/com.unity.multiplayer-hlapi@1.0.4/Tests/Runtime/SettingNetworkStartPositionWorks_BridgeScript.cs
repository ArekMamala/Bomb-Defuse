﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SettingNetworkStartPositionWorks_BridgeScript : MonoBehaviour
{
    public const string bridgeObjectName = "SettingNetworkStartPositionWorks_BridgeScriptGO";

    public GameObject playerPrefab;
}
